#include<iostream>
#include "List.h"
using namespace std;

List::List()
{
    head=NULL;
    tail=NULL;
}


void List::createnode(int value)
{
    return;
}


void List::display()
{
    return;
}


void List::insert_start(int value)
{
    return;
}


void List::insert_position(int pos, int value)
{
    return;
}


void List::delete_first()
{
    return;
}


void List::delete_last()
{
    return;
}


void List::delete_position(int pos)
{
    return;
}
